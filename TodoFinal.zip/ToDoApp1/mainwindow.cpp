#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "adddialog.h"
#include "ui_adddialog.h"
#include <QDate>
#include <QFile>
#include<QTextStream>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //set style sheet
    QFile styleSheetFile (":/new/prefix1/ElegantDark.qss");
    styleSheetFile.open(QIODevice::ReadOnly);
    QString styleSheet = QLatin1String(styleSheetFile.readAll());
    this->setStyleSheet(styleSheet);
    ui->setupUi(this);

    //Set QlistWidget backgroundcolor

    ui->Finished->setStyleSheet("QListWidget"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : green;"
                                     "}"
                                     "QListWidget QScrollBar"
                                     "{"
                                     "background : lightblue;"
                                     "}"
                                     "QListView::item:selected"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : light green;"
                                     "}"
                                     );
    ui->pendingTask->setStyleSheet("QListWidget"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : red;"
                                     "}"
                                     "QListWidget QScrollBar"
                                     "{"
                                     "background : lightblue;"
                                     "}"
                                     "QListView::item:selected"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : light pink;"
                                     "}"
                                     );
    ui->taskForToday->setStyleSheet("QListWidget"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : red;"
                                     "}"
                                     "QListWidget QScrollBar"
                                     "{"
                                     "background : lightblue;"
                                     "}"
                                     "QListView::item:selected"
                                     "{"
                                     "border : 2px solid black;"
                                     "background : light pink;"
                                    "color : black;"
                                     "}"
                                     );



}

void MainWindow::makeConnexions(){

    connect(ui->actionAdd_Task,&QAction::triggered,this,&MainWindow::on_actionAdd_Task_triggered);
    connect(ui->actionClose,&QAction::triggered,this,&MainWindow::close);
    connect(ui->actionTask_Done,&QAction::triggered,this,&MainWindow::on_actionTask_Done_triggered);
    connect(ui->actionHide_Finished, &QAction::triggered,this , &MainWindow::hideFinished);
    connect(ui->actionPending_Task, &QAction::triggered,this , &MainWindow::on_actionPending_Task_triggered);
    connect(ui->cacher, &QPushButton::clicked,this , &MainWindow::on_cacher_clicked);
    connect(ui->clearButton, &QPushButton::clicked,this , &MainWindow::on_pushButton_clicked);

}


void MainWindow::on_actionAdd_Task_triggered()
{

    addDialog D ;
    D.setModal(false);
    D.exec();


    QString newTask ;
    // Get the line edit text
    QString description = D.getDescription();
    if (description!=NULL){
        //Get Finished bool
        QString finished = D.getFinished();
    // Get current date
         QDate curDate = D.getDueDate();
        // QString date = D.getDueDate().toString();
        newTask = description +"\t Due:"+ curDate.toString() ;
        QString Tag= D.getTag();

         if (finished=="finished" || curDate < QDate::currentDate())
         {
             newTask = "Finished\t"+newTask+"\tTag :"+Tag+"\n";
              ui->Finished->addItem(new QListWidgetItem(QIcon(":/new/prefix1/done.png"),newTask));
}
         else if (curDate == QDate::currentDate()){
              newTask = "For Today\t"+newTask+"\tTag :"+Tag+"\n";
                ui->taskForToday->addItem(new QListWidgetItem(QIcon(":/new/prefix1/pending.png"),newTask));
         }
         else{
                 newTask = "Pending\t"+newTask+"\tTag :"+Tag+"\n";

                ui->pendingTask->addItem(new QListWidgetItem(QIcon(":/new/prefix1/pending.png"),newTask));

         }
    }
    QString fichier = "myFile.txt";

    QFile file(fichier); // Appel du constructeur de la classe QFile

    if (file.open(QIODevice::Append | QIODevice::Text)) {
    // Si l'ouverture du fichier en écriture à réussie

    // écrire dans le fichier en utilisant un flux :
    QTextStream out(&file);
    out << newTask;

    // Fermer le fichier
    file.close();
    }

}
void MainWindow::chargerTasks(QString myFile){
    QFile fichier(myFile);

    if(fichier.open(QIODevice::ReadOnly | QIODevice::Text)) // ReadOnly on lecture // ::Text si le fichier est deja ouvert
    {
        QTextStream flux(&fichier);
        while(!flux.atEnd())
        {
            QString temp = flux.readLine();
            if(  temp.startsWith("Finished"))
            ui->Finished->addItem(new QListWidgetItem(QIcon(":/new/prefix1/done.png"),temp));
            else if( temp.startsWith("Pending"))
                    ui->pendingTask->addItem(new QListWidgetItem(QIcon(":/new/prefix1/pending.png"),temp));
            else
                ui->taskForToday->addItem(new QListWidgetItem(QIcon(":/new/prefix1/pending.png"),temp));
        }
        fichier.close();
    }



}
void MainWindow::on_actionTask_Done_triggered()
{

    QString widget = ui->pendingTask->currentItem()->text();

    ui->Finished->addItem(new QListWidgetItem(QIcon(":/new/prefix1/done.png"),widget));

    QListWidgetItem *remWidget = ui->pendingTask->currentItem();
    delete remWidget;
}
void MainWindow::on_actionPending_Task_triggered()
{
    QString widget = ui->Finished->currentItem()->text();

    ui->pendingTask->addItem(new QListWidgetItem(QIcon(":/new/prefix1/pending.png"),widget));

    QListWidgetItem *remWidget = ui->Finished->currentItem();
    delete remWidget;
}
void MainWindow::hideFinished(){

   on_cacher_clicked();

}
void MainWindow::on_actionClose_triggered()
{
        qApp->quit();
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_cacher_clicked()
{
    ui->Finished->setVisible(false);
}


void MainWindow::on_pushButton_clicked()
{
    QFile file("/Users/makbookpro/build-ToDoApp1-Desktop_Qt_5_15_0_clang_64bit-Debug/ToDoApp1.app/Contents/MacOS/myFile.txt");
    file.open(QFile::WriteOnly|QFile::Truncate);
    ;

}

