#include "adddialog.h"
#include "ui_adddialog.h"
#include <QDate>

addDialog::addDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addDialog)
{
    ui->setupUi(this);
}
void addDialog::showEvent(QShowEvent * event)
{
    QDate date = QDate::currentDate();
    ui->dateEdit->setDate(date); // sets the current date to date edit.

    QDialog::showEvent(event);
}

QString addDialog::getDescription(){
    return ui->description->text();

}
QString addDialog::getFinished(){
    if (ui->checkBox->isChecked())
       return "finished";
    else
        return "pending";
}
QString addDialog::getTag(){

    return ui->comboBox->currentText();


}
QDate addDialog::getDueDate(){

    return ui->dateEdit->date();

}
addDialog::~addDialog()
{
    delete ui;
}



